#ifndef __PWM__H
#define __PWM__H

// #include "sys.h"
// #include "stdlib.h"	  
// #include "Delay.h"
#include "stm32f10x.h"
#include "stm32f10x_exti.h"


void GPIO_CFG();
void TIM2_PWM_Init(uint16_t period, uint16_t prescaler);

#endif


