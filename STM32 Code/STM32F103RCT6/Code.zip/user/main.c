#include "stm32f10x.h"
#include "beep.h"
#include "Delay.h"
#include "pwm.h"


int main (void)
{

	
   BEEP_Init();
	while(1)
	{
		play_music();
	}

}
